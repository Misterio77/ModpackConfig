

-Oceano (Owned and Operated by Cybox) EULA
 


*You ARE permitted to:

-Make youtube videos about Oceano/including Oceano.

-Feature Oceano on your website, although you MUST link to the offical Oceano page and not any other download source.


*You ARE permitted to with Cybox's EXPLICIT PERMISSION:
-Edit the shaders and share it with the internet. Note: Must be more than just value edits and be something meaningfull.
-Use Oceano's code.



*You are NOT permitted to:

-Claim any of Oceano's code as your own.

-Edit the shader then claim it as your own.

-Make money off of Oceano (This does not mean Youtube videos or such but redistributing the shader).
-Use different links that do not direct to the Official Oceano download page.